<div class="container-fluid" id="main">
	<div class="row">
		<div class="col-lg-12" id="left">
			<h1>Plan du site</h1>
			<ul>
				<li><a href="index.html">Accueil</a></li>
				<li><a href="agenda.html">Agenda des évènements</a></li>
				<li><a href="carte.html">Carte des évènements</a></li>
				<li><a href="wiki/start">La méthode GetUP</a></li>
				<li><a href="suggerersession.html">Suggérer une session GetUP</a></li>
				<li><a href="creersession.html">Créer une session GetUP</a></li>
				<li><a href="postuler.html">Postuler comme intervenant</a></li>
			</ul>
		</div> 
	</div>
</div>