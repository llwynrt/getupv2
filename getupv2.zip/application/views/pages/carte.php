<div class="container-fluid" id="main">
  <div class="row">
    <div class="col-lg-12" id="left">
      <iframe id="carte" src="http://getup-startup.com/gcm/?gc=+k8sog225cbf3afui8h1k72lf58%40group.calendar.google.com&ed=180" 
        scrolling="no" frameborder="0" style="width: 100%; height:600px">
      </iframe>
    </div> 
  </div>
</div>
